import { api, esc, escAttr, tokenKey } from './api.js';

/* ===== Авторизация / logout ===== */
const goLogin = () => { localStorage.removeItem(tokenKey); window.location.assign(`${location.origin}/index.html`); };
if (!api.token()) goLogin();
document.getElementById('logoutBtn')?.addEventListener('click', goLogin);

async function ensureAuth() {
    const me = await api.get('/auth/me');
    if (!me?.id) goLogin();
    return me;
}

/* ===== Элементы ===== */
const form = document.getElementById('fPhoto');
const msg = document.getElementById('msg');
const grid = document.getElementById('grid');

/* ===== Логика ===== */
async function loadPhotos() {
    await ensureAuth();
    const list = await api.get