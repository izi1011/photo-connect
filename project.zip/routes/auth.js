const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body } = require('express-validator');
const validate = require('../middlewares/validate');

const router = express.Router();
const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

// Утилиты для работы с пользователями
async function ensureUsersFile() {
    try {
        await fs.access(USERS_FILE);
    } catch (e) {
        await fs.mkdir(path.dirname(USERS_FILE), { recursive: true });
        await fs.writeFile(USERS_FILE, '[]', 'utf-8');
    }
}

async function readUsers() {
    await ensureUsersFile();
    const raw = await fs.readFile(USERS_FILE, 'utf-8');
    return raw.trim() ? JSON.parse(raw) : [];
}

async function writeUsers(users) {
    const json = JSON.stringify(users, null, 2);
    await fs.writeFile(USERS_FILE, json + '\n', 'utf-8');
}

// Регистрация
router.post('/register', [
    body('name')
        .trim()
        .notEmpty().withMessage('Имя обязательно')
        .isLength({ min: 2 }).withMessage('Имя должно быть не менее 2 символов'),
    body('email')
        .isEmail().withMessage('Некорректный email'),
    body('password')
        .isLength({ min: 6 }).withMessage('Пароль должен быть не менее 6 символов')
], validate, async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const users = await readUsers();

        const existingUser = users.find(u => u.email === email);
        if (existingUser) {
            return res.status(409).json({
                error: 'EMAIL_TAKEN',
                message: 'Пользователь с таким email уже существует'
            });
        }

        const hash = await bcrypt.hash(password, 10);

        const user = {
            id: Date.now(),
            name: name.trim(),
            email: email.toLowerCase().trim(),
            passwordHash: hash,
            createdAt: new Date().toISOString(),
            role: 'user'
        };

        users.push(user);
        await writeUsers(users);

        const token = jwt.sign(
            { id: user.id, email: user.email },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.status(201).json({
            id: user.id,
            name: user.name,
            email: user.email,
            token
        });
    } catch (err) {
        console.error('[POST /auth/register] error:', err);
        res.status(500).json({
            error: 'SERVER_ERROR',
            message: 'Ошибка при регистрации'
        });
    }
});

// Вход
router.post('/login', [
    body('email')
        .isEmail().withMessage('Некорректный email'),
    body('password')
        .notEmpty().withMessage('Пароль обязателен')
], validate, async (req, res) => {
    try {
        const { email, password } = req.body;

        const users = await readUsers();
        const user = users.find(u => u.email === email.toLowerCase().trim());

        if (!user) {
            return res.status(401).json({
                error: 'BAD_CREDENTIALS',
                message: 'Неверный email или пароль'
            });
        }

        const isValidPassword = await bcrypt.compare(password, user.passwordHash);
        if (!isValidPassword) {
            return res.status(401).json({
                error: 'BAD_CREDENTIALS',
                message: 'Неверный email или пароль'
            });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.json({
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            token
        });
    } catch (err) {
        console.error('[POST /auth/login] error:', err);
        res.status(500).json({
            error: 'SERVER_ERROR',
            message: 'Ошибка при входе'
        });
    }
});

// Получение данных текущего пользователя
router.get('/me', require('../middlewares/auth'), async (req, res) => {
    try {
        const users = await readUsers();
        const user = users.find(u => u.id === req.userId);

        if (!user) {
            return res.status(404).json({
                error: 'USER_NOT_FOUND',
                message: 'Пользователь не найден'
            });
        }

        const { passwordHash, ...userData } = user;
        res.json(userData);
    } catch (err) {
        console.error('[GET /auth/me] error:', err);
        res.status(500).json({
            error: 'SERVER_ERROR',
            message: 'Ошибка при получении данных'
        });
    }
});

module.exports = router;