const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const { body } = require('express-validator');
const validate = require('../middlewares/validate');

const router = express.Router();
const DATA_FILE = path.join(__dirname, '..', 'data', 'friends.json');

// Утилиты
async function ensureDataFile() {
    try {
        await fs.access(DATA_FILE);
    } catch (e) {
        await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
        await fs.writeFile(DATA_FILE, '[]', 'utf-8');
    }
}

async function readFriends() {
    await ensureDataFile();
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    return raw.trim() ? JSON.parse(raw) : [];
}

async function writeFriends(friends) {
    const json = JSON.stringify(friends, null, 2);
    await fs.writeFile(DATA_FILE, json + '\n', 'utf-8');
}

// GET /api/friends
router.get('/', async (req, res) => {
    try {
        const friends = await readFriends();
        res.json(friends);
    } catch (err) {
        console.error('[GET /api/friends] read error:', err);
        res.status(500).json({ error: 'Не удалось получить список друзей' });
    }
});

// POST /api/friends
router.post(
    '/',
    [
        body('name')
            .trim()
            .notEmpty().withMessage('Имя обязательно')
    ],
    validate,
    async (req, res) => {
        try {
            const { name, note } = req.body;

            const friend = {
                id: Date.now(),
                name: name.trim(),
                note: (note || '').trim(),
                createdAt: new Date().toISOString()
            };

            const friends = await readFriends();
            friends.unshift(friend);
            await writeFriends(friends);

            res.status(201).json(friend);
        } catch (err) {
            console.error('[POST /api/friends] write error:', err);
            res.status(500).json({ error: 'Не удалось добавить друга' });
        }
    }
);

module.exports = router;