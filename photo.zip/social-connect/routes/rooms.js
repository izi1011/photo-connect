const express = require('express');
const fs = require('fs').promises;
const path = require('path');

const router = express.Router();
const DATA_FILE = path.join(__dirname, '..', 'data', 'rooms.json');

async function ensureDataFile() {
    try {
        await fs.access(DATA_FILE);
    } catch (e) {
        await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
        await fs.writeFile(DATA_FILE, '[]', 'utf-8');
    }
}

async function readRooms() {
    await ensureDataFile();
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    return raw.trim() ? JSON.parse(raw) : [];
}

async function writeRooms(rooms) {
    const json = JSON.stringify(rooms, null, 2);
    await fs.writeFile(DATA_FILE, json + '\n', 'utf-8');
}

// GET /api/rooms
router.get('/', async (req, res) => {
    try {
        const rooms = await readRooms();
        res.json(rooms);
    } catch (err) {
        console.error('[GET /api/rooms] read error:', err);
        res.status(500).json({ error: 'Не удалось получить список номеров' });
    }
});

// POST /api/rooms
router.post('/', async (req, res) => {
    try {
        const { roomNumber, type, price } = req.body || {};

        if (!roomNumber || !type || !price) {
            return res.status(400).json({ error: 'Все поля обязательны' });
        }

        const room = {
            id: Date.now(),
            roomNumber: String(roomNumber).trim(),
            type: String(type).trim(),
            price: Number(price),
            createdAt: new Date().toISOString()
        };

        const rooms = await readRooms();
        rooms.push(room);
        await writeRooms(rooms);

        res.status(201).json(room);
    } catch (err) {
        console.error('[POST /api/rooms] write error:', err);
        res.status(500).json({ error: 'Не удалось добавить номер' });
    }
});

module.exports = router;