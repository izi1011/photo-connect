const { Router } = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const auth = require('../middlewares/auth');

const router = Router();

router.post('/register', async (req, res) => {
    const { name = '', email = '', password = '' } = req.body;
    if (!name.trim() || !email.trim() || password.length < 6)
        return res.status(400).json({ error: 'VALIDATION' });

    const [ex] = await pool.query('SELECT id FROM users WHERE email=?', [email]);
    if (ex.length) return res.status(409).json({ error: 'EMAIL_TAKEN' });

    const hash = await bcrypt.hash(password, 10);
    const [r] = await pool.query(
        'INSERT INTO users(name,email,password_hash) VALUES (?,?,?)',
        [name, email, hash]
    );
    res.json({ id: r.insertId, name, email });
});

router.post('/login', async (req, res) => {
    const { email = '', password = '' } = req.body;
    const [u] = await pool.query('SELECT * FROM users WHERE email=?', [email]);
    if (!u.length) return res.status(401).json({ error: 'BAD_CREDENTIALS' });
    const ok = await bcrypt.compare(password, u[0].password_hash);
    if (!ok) return res.status(401).json({ error: 'BAD_CREDENTIALS' });
    const token = jwt.sign({ id: u[0].id }, process.env.JWT_SECRET, { expiresIn: '2h' });
    res.json({ token });
});

router.get('/me', auth, async (req, res) => {
    const [u] = await pool.query(
        'SELECT id, name, email, role, avatar_url, bio, birth_date, social_links FROM users WHERE id=?',
        [req.userId]
    );
    res.json(u[0] || null);
});

module.exports = router;
