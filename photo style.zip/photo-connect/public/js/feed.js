import { api, tokenKey, fmtDate, esc, escAttr } from './api.js';

/* ===== Общие утилиты ===== */
const goLogin = () => { localStorage.removeItem(tokenKey); window.location.assign(`${location.origin}/index.html`); };
document.getElementById('logoutBtn')?.addEventListener('click', goLogin);

async function ensureAuth() {
    if (!api.token()) { goLogin(); return null; }
    const me = await api.get('/auth/me');
    if (!me?.id) { goLogin(); return null; }
    return me;
}

/* ===== Профиль (profile.html): профиль + мои посты + форма нового поста ===== */
const profileBox = document.getElementById('profileBox');
const myFeed = document.getElementById('myFeed');
const postForm = document.getElementById('postForm');
const postMsg = document.getElementById('postMsg');

async function loadProfile() {
    if (!profileBox) return;
    const me = await ensureAuth(); if (!me) return;
    profileBox.innerHTML = `
    <div><b>Имя:</b> ${esc(me.name || '')}</div>
    <div class="muted"><b>Email:</b> ${esc(me.email || '')}</div>
  `;
}

async function loadMyFeed() {
    if (!myFeed) return;
    const list = await api.get('/posts/my');
    if (!Array.isArray(list) || !list.length) {
        myFeed.classList.add('placeholder');
        myFeed.textContent = 'Пока нет записей';
        return;
    }
    myFeed.classList.remove('placeholder');
    myFeed.innerHTML = list.map(p => `
    <article>
      <div class="meta"><b>${esc(p.author || '')}</b> • ${fmtDate(p.created_at)}</div>
      <div class="text">${esc(p.content || '')}</div>
      ${p.photo_url ? `<img src="${escAttr(p.photo_url)}" alt="photo">` : ''}
    </article>
  `).join('');
}

postForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    postMsg && (postMsg.textContent = '');
    const body = Object.fromEntries(new FormData(postForm));
    const r = await api.post('/posts', body);
    if (r?.id) {
        postForm.reset();
        loadMyFeed();
    } else {
        postMsg && (postMsg.textContent = r?.error === 'CONTENT_REQUIRED' ? 'Введите текст поста' : 'Ошибка публикации');
    }
});

/* ===== Лента (feed.html): общая лента всех пользователей ===== */
const feed = document.getElementById('feed');

async function loadFeed() {
    if (!feed) return;
    const list = await api.get('/posts');
    if (!Array.isArray(list) || !list.length) {
        feed.classList.add('placeholder');
        feed.textContent = 'Лента пуста';
        return;
    }
    feed.classList.remove('placeholder');
    feed.innerHTML = list.map(p => `
    <article>
      <div class="meta"><b>${esc(p.author || '')}</b> • ${fmtDate(p.created_at)}</div>
      <div class="text">${esc(p.content || '')}</div>
      ${p.photo_url ? `<img src="${escAttr(p.photo_url)}" alt="photo">` : ''}
    </article>
  `).join('');
}

/* ===== Старт страниц ===== */
if (profileBox || myFeed) { ensureAuth().then(() => { loadProfile(); loadMyFeed(); }); }
if (feed) { loadFeed(); }