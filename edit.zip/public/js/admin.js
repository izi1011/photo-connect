// public/js/admin.js
import { api, tokenKey } from './api.js';

const $  = (s, r=document) => r.querySelector(s);
let users = [];

/* --- пускаем только администратора --- */
async function guard() {
    const t = api.token();
    if (!t) { location.replace(`${location.origin}/index.html`); return false; }
    const me = await api.get('/auth/me').catch(() => null);
    if (!me || me.role !== 'admin') {
        alert('Доступ только для администратора');
        location.replace(`${location.origin}/pages/profile.html`);
        return false;
    }
    return true;
}

/* --- загрузка и рендер --- */
async function loadUsers() {
    const list = await api.get('/admin/users').catch(() => []);
    users = Array.isArray(list) ? list : [];
    render(users);
}

function render(list) {
    const tbody = $('#usersTable');
    if (!tbody) return;
    tbody.innerHTML = list.map(u => `
    <tr data-id="${u.id}">
      <td>${escapeHtml(u.name ?? '')}</td>
      <td>${escapeHtml(u.email ?? '')}</td>
      <td>${u.avatar_url ? `<img src="${u.avatar_url}" width="40" height="40" style="border-radius:6px;object-fit:cover">` : '—'}</td>
      <td><button class="btn-delete">Удалить</button></td>
    </tr>
  `).join('');
}

/* --- делегирование кликов по таблице --- */
$('#usersTable')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('.btn-delete');
    if (!btn) return;
    const tr = e.target.closest('tr[data-id]');
    const id = Number(tr?.dataset.id || 0);
    const user = users.find(u => u.id === id);
    if (!id || !user) return;

    if (!confirm(`Удалить пользователя #${id} (${user.email})? Это необратимо.`)) return;

    try {
        const res = await fetch(`/admin/users/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${api.token()}`, 'Accept': 'application/json' }
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data?.error) throw new Error(data?.error || `HTTP ${res.status}`);
        // локально обновляем
        users = users.filter(u => u.id !== id);
        render(users);
    } catch (err) {
        alert(`Не удалось удалить: ${err.message || err}`);
    }
});

/* --- кнопка «Выйти» --- */
$('#logoutBtn')?.addEventListener('click', (e) => {
    e.preventDefault();
    localStorage.removeItem(tokenKey);      // или api.setToken(null), если реализовано
    location.assign(`${location.origin}/index.html`);
});

/* --- утилиты --- */
function escapeHtml(s=''){ return s.replace(/[&<>"']/g,c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

/* --- старт --- */
(async function start(){
    const ok = await guard();
    if (!ok) return;
    await loadUsers();
})();
