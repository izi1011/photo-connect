const API = '/api/items';
const form = document.getElementById('form');
const list = document.getElementById('list');
const imageInput = document.getElementById('image');
const imagePreview = document.getElementById('imagePreview');

async function loadItems() {
    const sort = document.getElementById('sortSelect').value;
    const res = await fetch(`${API}?sort=${sort}`);
    const data = await res.json();
    list.innerHTML = data.map(i => `
    <div style="margin-bottom:10px">
      <b>${i.title}</b> --- ${i.note}<br>
      <small>Создано: ${new Date(i.date_created).toLocaleString()}</small><br>
      ${i.image ? `<img src="${i.image}" width="100">` : ''}
      <br>
      <button onclick="edit(${i.id}, '${i.title}', '${i.note}')">✏️</button>
      <button onclick="del(${i.id})">🗑️</button>
    </div>
  `).join('');
}

form.addEventListener('submit', async e => {
    e.preventDefault();
    const id = document.getElementById('id').value;
    const title = document.getElementById('title').value;
    const note = document.getElementById('note').value;
    const image = document.getElementById('image').files[0];

    const formData = new FormData();
    formData.append('title', title);
    formData.append('note', note);
    if (image) formData.append('image', image);

    const method = id ? 'PUT' : 'POST';
    const url = id ? `${API}/${id}` : API;

    await fetch(url, { method, body: formData });

    form.reset();
    document.getElementById('id').value = '';
    imagePreview.innerHTML = '';
    loadItems();
});

function edit(id, title, note) {
    document.getElementById('id').value = id;
    document.getElementById('title').value = title;
    document.getElementById('note').value = note;
    imagePreview.innerHTML = '';
    document.getElementById('image').value = '';
}

async function del(id) {
    if (confirm('Удалить запись?')) {
        await fetch(`${API}/${id}`, { method: 'DELETE' });
        loadItems();
    }
}

imageInput.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            imagePreview.innerHTML = `<img src="${e.target.result}" width="150" style="border: 1px solid #ccc">`;
        }
        reader.readAsDataURL(file);
    } else {
        imagePreview.innerHTML = '';
    }
});

loadItems();