require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

//  статика по абсолютному пути (исправляет 404 на Windows)
app.use(express.static(path.join(__dirname, 'public')));

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

app.use('/auth', require('./routes/auth'));
app.use('/posts', require('./routes/posts'));
app.use('/friends', require('./routes/friends'));
app.use('/photos', require('./routes/photos'));
app.use('/admin', require('./routes/admin'));
app.use('/profile', require('./routes/profile'));

app.use((err, _req, res, _next) => {
    console.error('Unhandled:', err);
    res.status(500).json({ error: 'SERVER_ERROR' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ http://localhost:${PORT}`));
