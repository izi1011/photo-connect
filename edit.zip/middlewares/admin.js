const pool = require('../db');

module.exports = async function (req, res, next) {
    const [rows] = await pool.query('SELECT role FROM users WHERE id=?', [req.userId]);
    if (!rows.length || rows[0].role !== 'admin')
        return res.status(403).json({ error: 'FORBIDDEN' });
    next();
};
