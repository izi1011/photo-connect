const { Router } = require('express');
const pool = require('../db');
const auth = require('../middlewares/auth');
const multer = require('multer');
const path = require('path');

const upload = multer({ dest: path.join(__dirname, '../public/avatars') });
const router = Router();

router.put('/me', auth, async (req, res) => {
    const { name, bio, birth_date, social_links } = req.body;
    await pool.query('UPDATE users SET name=?, bio=?, birth_date=?, social_links=? WHERE id=?',
        [name, bio, birth_date, social_links, req.userId]);
    res.json({ ok: true });
});

router.post('/avatar', auth, upload.single('avatar'), async (req, res) => {
    const avatarPath = `/avatars/${req.file.filename}`;
    await pool.query('UPDATE users SET avatar_url=? WHERE id=?', [avatarPath, req.userId]);
    res.json({ avatar_url: avatarPath });
});

module.exports = router;
