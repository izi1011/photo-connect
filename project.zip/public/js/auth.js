// API утилиты
const API_BASE = '';

const authAPI = {
    async request(path, method = 'GET', body) {
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json'
            }
        };

        // Добавляем токен если есть
        const token = localStorage.getItem('hoteltime_token');
        if (token) {
            options.headers.Authorization = `Bearer ${token}`;
        }

        if (body) {
            options.body = JSON.stringify(body);
        }

        try {
            const response = await fetch(`${API_BASE}${path}`, options);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `HTTP ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    },

    register(userData) {
        return this.request('/api/auth/register', 'POST', userData);
    },

    login(credentials) {
        return this.request('/api/auth/login', 'POST', credentials);
    },

    getMe() {
        return this.request('/api/auth/me');
    }
};

// Утилиты для работы с UI
const authUI = {
    showMessage(element, message, type = 'error') {
        element.textContent = message;
        element.className = `auth-message ${type}`;
        element.style.display = 'block';

        if (type === 'success') {
            setTimeout(() => {
                element.style.display = 'none';
            }, 3000);
        }
    },

    clearMessages() {
        const loginMessage = document.getElementById('loginMessage');
        const registerMessage = document.getElementById('registerMessage');
        if (loginMessage) loginMessage.style.display = 'none';
        if (registerMessage) registerMessage.style.display = 'none';
    },

    setLoading(button, isLoading) {
        if (isLoading) {
            button.disabled = true;
            button.textContent = 'Загрузка...';
        } else {
            button.disabled = false;
            const originalText = button.dataset.originalText || 'Отправить';
            button.textContent = originalText;
        }
    }
};

// Переключение между вкладками
function initTabs() {
    const tabs = document.querySelectorAll('.auth-tab');
    const forms = document.querySelectorAll('.auth-form');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.dataset.tab;

            // Активируем вкладку
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // Показываем соответствующую форму
            forms.forEach(form => {
                form.classList.remove('active');
                if (form.id === `${targetTab}Form`) {
                    form.classList.add('active');
                }
            });

            // Очищаем сообщения
            authUI.clearMessages();
        });
    });
}

// Обработка формы входа
function initLoginForm() {
    const form = document.getElementById('loginForm');
    if (!form) return;

    const messageEl = document.getElementById('loginMessage');
    const submitBtn = form.querySelector('button');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        authUI.clearMessages();

        const formData = new FormData(form);
        const credentials = {
            email: formData.get('email'),
            password: formData.get('password')
        };

        // Сохраняем оригинальный текст кнопки
        if (!submitBtn.dataset.originalText) {
            submitBtn.dataset.originalText = submitBtn.textContent;
        }

        authUI.setLoading(submitBtn, true);

        try {
            const result = await authAPI.login(credentials);

            // Сохраняем токен
            localStorage.setItem('hoteltime_token', result.token);
            localStorage.setItem('hoteltime_user', JSON.stringify({
                id: result.id,
                name: result.name,
                email: result.email
            }));

            if (messageEl) {
                authUI.showMessage(messageEl, `Добро пожаловать, ${result.name}!`, 'success');
            }

            // Перенаправляем на главную через 1 секунду
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1000);

        } catch (error) {
            if (messageEl) {
                authUI.showMessage(messageEl, error.message || 'Ошибка при входе');
            }
        } finally {
            authUI.setLoading(submitBtn, false);
        }
    });
}

// Обработка формы регистрации
function initRegisterForm() {
    const form = document.getElementById('registerForm');
    if (!form) return;

    const messageEl = document.getElementById('registerMessage');
    const submitBtn = form.querySelector('button');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        authUI.clearMessages();

        const formData = new FormData(form);
        const userData = {
            name: formData.get('name'),
            email: formData.get('email'),
            password: formData.get('password')
        };

        // Сохраняем оригинальный текст кнопки
        if (!submitBtn.dataset.originalText) {
            submitBtn.dataset.originalText = submitBtn.textContent;
        }

        authUI.setLoading(submitBtn, true);

        try {
            const result = await authAPI.register(userData);

            if (messageEl) {
                authUI.showMessage(messageEl, 'Регистрация успешна! Теперь вы можете войти.', 'success');
            }

            // НЕ переключаем на вкладку входа автоматически!
            // Оставляем пользователя на форме регистрации
            setTimeout(() => {
                if (messageEl) {
                    messageEl.style.display = 'none';
                }
                // Только очищаем форму
                form.reset();
            }, 3000);

        } catch (error) {
            if (messageEl) {
                authUI.showMessage(messageEl, error.message || 'Ошибка при регистрации');
            }
        } finally {
            authUI.setLoading(submitBtn, false);
        }
    });
}

// Проверка авторизации при загрузке страницы
function checkAuth() {
    const token = localStorage.getItem('hoteltime_token');
    const currentPage = window.location.pathname;

    // Если на странице auth.html и уже авторизован - редирект на главную
    if (currentPage.includes('auth.html') && token) {
        console.log('Already authenticated, redirecting to main page');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 100);
        return;
    }

    // Если НЕ на странице auth.html и НЕ авторизован - редирект на auth
    if (!currentPage.includes('auth.html') && !token) {
        console.log('Not authenticated, redirecting to auth');
        setTimeout(() => {
            window.location.href = 'auth.html';
        }, 100);
        return;
    }
}

// Обновляем данные пользователя на странице
function updateUserUI() {
    const user = window.auth.getUser();
    const userInfo = document.getElementById('userInfo');
    const authButtons = document.getElementById('authButtons');
    const userName = document.getElementById('userName');

    if (user && userInfo && userName) {
        userName.textContent = user.name;
        userInfo.style.display = 'block';
        if (authButtons) authButtons.style.display = 'none';
    } else if (authButtons) {
        authButtons.style.display = 'block';
        if (userInfo) userInfo.style.display = 'none';
    }
}

// Инициализация
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    initTabs();
    initLoginForm();
    initRegisterForm();
});

// Глобальные функции для других скриптов
window.auth = {
    isAuthenticated() {
        return !!localStorage.getItem('hoteltime_token');
    },

    getUser() {
        const userStr = localStorage.getItem('hoteltime_user');
        return userStr ? JSON.parse(userStr) : null;
    },

    logout() {
        localStorage.removeItem('hoteltime_token');
        localStorage.removeItem('hoteltime_user');
        window.location.href = 'auth.html';
    },

    async getCurrentUser() {
        try {
            const user = await authAPI.getMe();
            return user;
        } catch (error) {
            this.logout();
            return null;
        }
    }
};