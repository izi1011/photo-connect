const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const auth = require('../middlewares/auth');

const router = express.Router();
const BOOKINGS_FILE = path.join(__dirname, '..', 'data', 'bookings.json');

// Утилиты для работы с бронированиями
async function ensureBookingsFile() {
    try {
        await fs.access(BOOKINGS_FILE);
    } catch (e) {
        await fs.mkdir(path.dirname(BOOKINGS_FILE), { recursive: true });
        await fs.writeFile(BOOKINGS_FILE, '[]', 'utf-8');
    }
}

async function readBookings() {
    await ensureBookingsFile();
    const raw = await fs.readFile(BOOKINGS_FILE, 'utf-8');
    return raw.trim() ? JSON.parse(raw) : [];
}

async function writeBookings(bookings) {
    const json = JSON.stringify(bookings, null, 2);
    await fs.writeFile(BOOKINGS_FILE, json + '\n', 'utf-8');
}

// Получение бронирований пользователя
router.get('/my', auth, async (req, res) => {
    try {
        const bookings = await readBookings();
        const userBookings = bookings.filter(booking => booking.userId === req.userId);

        res.json(userBookings);
    } catch (err) {
        console.error('[GET /api/bookings/my] error:', err);
        res.status(500).json({
            error: 'SERVER_ERROR',
            message: 'Ошибка при получении бронирований'
        });
    }
});

// Создание бронирования
router.post('/', auth, async (req, res) => {
    try {
        const { room, checkIn, checkOut, guestName, guestEmail, guestPhone, guestsCount, specialRequests } = req.body;

        if (!room || !checkIn || !checkOut) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Необходимо указать номер, даты заезда и выезда'
            });
        }

        const booking = {
            id: Date.now(),
            userId: req.userId,
            userEmail: req.userEmail,
            room,
            checkIn,
            checkOut,
            guestName,
            guestEmail,
            guestPhone,
            guestsCount: guestsCount || 2,
            specialRequests: specialRequests || '',
            totalPrice: calculateTotalPrice(room.price, checkIn, checkOut),
            status: 'confirmed',
            createdAt: new Date().toISOString()
        };

        const bookings = await readBookings();
        bookings.push(booking);
        await writeBookings(bookings);

        res.status(201).json(booking);
    } catch (err) {
        console.error('[POST /api/bookings] error:', err);
        res.status(500).json({
            error: 'SERVER_ERROR',
            message: 'Ошибка при создании бронирования'
        });
    }
});

// Вспомогательная функция для расчета стоимости
function calculateTotalPrice(pricePerNight, checkIn, checkOut) {
    const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));
    return nights * pricePerNight;
}

module.exports = router;