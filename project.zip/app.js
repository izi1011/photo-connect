const express = require('express');
const path = require('path');
require('dotenv').config();

const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Health check
app.get('/health', (_req, res) => res.json({ status: 'ok' }));

// API routes
app.use('/api/rooms', require('./routes/rooms'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/bookings', require('./routes/bookings')); // Добавляем бронирования

// Error handler
app.use((err, _req, res, _next) => {
    console.error('Unhandled:', err);
    res.status(500).json({ error: 'SERVER_ERROR' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`HotelTime: http://localhost:${PORT}`));