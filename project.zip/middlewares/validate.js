const { validationResult } = require('express-validator');

module.exports = (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) return next();

    const details = errors.array().map(e => ({
        field: e.path,
        message: e.msg
    }));

    res.status(400).json({
        error: 'VALIDATION_ERROR',
        details
    });
};