(function initBooking() {
    const bookingForm = document.getElementById('bookingForm');
    const errorsBox = document.getElementById('errorBox');
    const errorsList = document.getElementById('errors');
    const roomSummary = document.getElementById('roomSummary');
    const selectedRoomNumber = document.getElementById('selectedRoomNumber');
    const selectedRoomType = document.getElementById('selectedRoomType');
    const selectedRoomPrice = document.getElementById('selectedRoomPrice');
    const selectedPeriod = document.getElementById('selectedPeriod');
    const totalPrice = document.getElementById('totalPrice');
    const checkInInput = document.getElementById('bookingCheckIn');
    const checkOutInput = document.getElementById('bookingCheckOut');

    if (!bookingForm) return;

    let selectedRoom = null;

    // Утилиты
    function clearErrors() {
        if (errorsBox) errorsBox.style.display = 'none';
        if (errorsList) errorsList.innerHTML = '';
        bookingForm.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
    }

    function showErrors(details) {
        if (errorsBox) errorsBox.style.display = '';
        if (window.renderErrors) window.renderErrors(details, errorsList);
        if (window.highlightFields) window.highlightFields(details, bookingForm);
        (errorsBox || errorsList)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function escapeHtml(str = '') {
        return String(str)
            .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;').replaceAll("'", '&#039;');
    }

    // Проверка авторизации
    function checkAuth() {
        if (!window.auth || !window.auth.isAuthenticated()) {
            alert('Для бронирования номера необходимо войти в систему.');
            window.location.href = '/auth.html';
            return false;
        }
        return true;
    }

    // Загрузка выбранного номера
    function loadSelectedRoom() {
        if (!checkAuth()) return;

        const roomData = JSON.parse(localStorage.getItem('selectedRoom') || 'null');

        if (!roomData) {
            alert('Номер не выбран! Вернитесь в каталог.');
            window.location.href = '/pages/rooms.html';
            return;
        }

        selectedRoom = roomData;

        // Заполняем summary
        selectedRoomNumber.textContent = roomData.roomNumber;
        selectedRoomType.textContent = roomData.type;
        selectedRoomPrice.textContent = roomData.price + ' ₽';

        // Устанавливаем даты если есть из поиска
        if (roomData.checkIn) checkInInput.value = roomData.checkIn;
        if (roomData.checkOut) checkOutInput.value = roomData.checkOut;

        roomSummary.style.display = 'block';
        calculateTotal();
    }

    // Расчет общей стоимости
    function calculateTotal() {
        if (!selectedRoom || !checkInInput.value || !checkOutInput.value) return;

        const checkIn = new Date(checkInInput.value);
        const checkOut = new Date(checkOutInput.value);

        if (checkIn >= checkOut) return;

        const nights = Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
        const total = nights * selectedRoom.price;

        selectedPeriod.textContent = `${nights} ночей (${checkInInput.value} - ${checkOutInput.value})`;
        totalPrice.textContent = total + ' ₽';
    }

    // Валидация формы
    function validateForm(formData) {
        const details = [];
        const { checkIn, checkOut, guestName, guestEmail, guestPhone } = formData;

        if (!checkIn) details.push({ field: 'checkIn', message: 'Дата заезда обязательна' });
        if (!checkOut) details.push({ field: 'checkOut', message: 'Дата выезда обязательна' });
        if (!guestName) details.push({ field: 'guestName', message: 'ФИО обязательно' });
        if (!guestEmail) details.push({ field: 'guestEmail', message: 'Email обязателен' });
        if (!guestPhone) details.push({ field: 'guestPhone', message: 'Телефон обязателен' });

        // Валидация дат
        if (checkIn && checkOut) {
            const checkInDate = new Date(checkIn);
            const checkOutDate = new Date(checkOut);

            if (checkInDate >= checkOutDate) {
                details.push({ field: 'checkOut', message: 'Дата выезда должна быть позже даты заезда' });
            }

            if (checkInDate < new Date().setHours(0,0,0,0)) {
                details.push({ field: 'checkIn', message: 'Дата заезда не может быть в прошлом' });
            }
        }

        // Валидация email
        if (guestEmail && !/.+@.+\..+/.test(guestEmail)) {
            details.push({ field: 'guestEmail', message: 'Некорректный email' });
        }

        return details;
    }

    // Обработчик отправки формы
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();

        if (!checkAuth()) return;

        clearErrors();

        const formData = {
            checkIn: checkInInput.value,
            checkOut: checkOutInput.value,
            guestName: document.getElementById('guestName').value.trim(),
            guestEmail: document.getElementById('guestEmail').value.trim(),
            guestPhone: document.getElementById('guestPhone').value.trim(),
            guestsCount: document.getElementById('guestsCount').value,
            specialRequests: document.getElementById('specialRequests').value.trim()
        };

        const errors = validateForm(formData);
        if (errors.length) {
            showErrors(errors);
            return;
        }

        // Получаем данные пользователя
        const user = window.auth.getUser();
        if (!user) {
            alert('Ошибка авторизации. Пожалуйста, войдите снова.');
            window.auth.logout();
            return;
        }

        // Создаем объект бронирования
        const booking = {
            id: Date.now(),
            userId: user.id,
            userEmail: user.email,
            userName: user.name,
            room: selectedRoom,
            ...formData,
            totalPrice: totalPrice.textContent,
            createdAt: new Date().toISOString(),
            status: 'pending'
        };

        // Сохраняем бронь в localStorage (в реальном приложении отправляем на сервер)
        const bookings = JSON.parse(localStorage.getItem('hoteltime_bookings') || '[]');
        bookings.push(booking);
        localStorage.setItem('hoteltime_bookings', JSON.stringify(bookings));

        // Сохраняем в историю бронирований пользователя
        const userBookings = JSON.parse(localStorage.getItem(`user_${user.id}_bookings`) || '[]');
        userBookings.push(booking);
        localStorage.setItem(`user_${user.id}_bookings`, JSON.stringify(userBookings));

        alert(`Бронь оформлена! Номер брони: #${booking.id}\nНа email ${user.email} отправлено подтверждение.`);
        bookingForm.reset();
        localStorage.removeItem('selectedRoom');
        window.location.href = '/index.html';
    });

    // Слушатели изменения дат для пересчета стоимости
    checkInInput.addEventListener('change', calculateTotal);
    checkOutInput.addEventListener('change', calculateTotal);

    // Инициализация
    loadSelectedRoom();
})();