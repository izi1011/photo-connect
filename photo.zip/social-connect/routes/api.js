const express = require('express');
const fs = require('fs').promises;
const path = require('path');

const router = express.Router();
const DATA_FILE = path.join(__dirname, '..', 'data', 'posts.json');

// ---------Утилиты работы с JSON-хранилищем--------
async function ensureDataFile() {
    try {
        await fs.access(DATA_FILE);
    } catch (e) {
        await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
        await fs.writeFile(DATA_FILE, '[]', 'utf-8');
    }
}

async function readPosts() {
    await ensureDataFile();
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    return raw.trim() ? JSON.parse(raw) : [];
}

async function writePosts(posts) {
    const json = JSON.stringify(posts, null, 2);
    await fs.writeFile(DATA_FILE, json + '\n', 'utf-8');
}
//-----------------------Маршруты апи-----------------

// GET /api/posts
router.get('/', async (req, res) => {
    try {
        const posts = await readPosts();
        posts.sort((a, b) => new Date(b.createAt) - new Date(a.createAt));
        res.json(posts);
    } catch (err) {
        console.error('[GET /api/posts] read error:', err);
        res.status(500).json({ error: 'Не удалось прочитать ленту' });
    }
});

// POST /api/posts - публикация и сохранение в джсон
router.post('/', async (req, res) => {
    try {
        const { author, content } = req.body || {};
        if (!author || !content) {
            return res.status(400).json({ error: 'Поля author и content обязательны' });
        }

        const post = {
            id: Date.now(),
            author: String(author).trim().slice(0, 100),
            content: String(content).trim().slice(0, 2000),
            createAt: new Date().toISOString()
        };

        const posts = await readPosts();
        posts.push(post);
        await writePosts(posts);

        res.status(201).json(post);
    } catch (err) {
        console.error('[POST /api/posts] write error:', err);
        res.status(500).json({ error: 'Не удалось сохранить публикацию' });
    }
});

module.exports = router;