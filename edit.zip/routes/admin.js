const { Router } = require('express');
const pool = require('../db');
const auth = require('../middlewares/auth');
const admin = require('../middlewares/admin');

const router = Router();

router.get('/users', auth, admin, async (_req, res) => {
    const [users] = await pool.query('SELECT id, name, email, bio, birth_date, social_links, avatar_url FROM users');
    res.json(users);
});

router.put('/users/:id', auth, admin, async (req, res) => {
    const { name, bio, birth_date, social_links } = req.body;
    await pool.query('UPDATE users SET name=?, bio=?, birth_date=?, social_links=? WHERE id=?',
        [name, bio, birth_date, social_links, req.params.id]);
    res.json({ ok: true });
});

router.delete('/users/:id', auth, admin, async (req, res) => {
    await pool.query('DELETE FROM users WHERE id=?', [req.params.id]);
    res.json({ ok: true });
});

module.exports = router;
