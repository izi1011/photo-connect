(function initRooms() {
    const roomsList = document.getElementById('roomsList');
    const typeFilter = document.getElementById('typeFilter');
    const priceFilter = document.getElementById('priceFilter');
    const applyFilters = document.getElementById('applyFilters');

    if (!roomsList) return;

    let allRooms = [];
    let filteredRooms = [];

    // Утилиты
    function escapeHtml(str = '') {
        return String(str)
            .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;').replaceAll("'", '&#039;');
    }

    // Проверка авторизации
    function checkAuth() {
        if (!window.auth || !window.auth.isAuthenticated()) {
            if (confirm('Для бронирования номера необходимо войти в систему. Перейти на страницу входа?')) {
                window.location.href = '/auth.html';
            }
            return false;
        }
        return true;
    }

    // Загрузка номеров
    async function loadRooms() {
        try {
            const res = await fetch('/api/rooms');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            allRooms = await res.json();
            applyFilter();
        } catch (err) {
            console.error('Ошибка загрузки номеров:', err);
            roomsList.innerHTML = '<div class="placeholder">Ошибка загрузки номеров</div>';
        }
    }

    // Фильтрация
    function applyFilter() {
        const typeValue = typeFilter.value;
        const priceValue = priceFilter.value;

        filteredRooms = allRooms.filter(room => {
            const typeMatch = !typeValue || room.type === typeValue;
            const priceMatch = !priceValue || room.price <= Number(priceValue);
            return typeMatch && priceMatch;
        });

        renderRooms(filteredRooms);
    }

    // Рендер номеров
    function renderRooms(rooms) {
        if (!rooms || !rooms.length) {
            roomsList.innerHTML = '<div class="placeholder">Номера не найдены</div>';
            return;
        }

        roomsList.innerHTML = rooms.map(room => `
            <div class="room-card">
                <div class="room-header">
                    <div class="room-number">№${escapeHtml(room.roomNumber)}</div>
                    <div class="type-badge">${escapeHtml(room.type)}</div>
                </div>
                <div class="room-price">${room.price} ₽/ночь</div>
                <div class="room-meta">Добавлен: ${new Date(room.createdAt).toLocaleDateString()}</div>
                <button class="book-btn" onclick="bookRoom(${room.id}, '${escapeHtml(room.roomNumber)}', '${escapeHtml(room.type)}', ${room.price})">
                    🗓️ Забронировать
                </button>
            </div>
        `).join('');
    }

    // Бронирование - переход на страницу брони
    window.bookRoom = function(roomId, roomNumber, roomType, roomPrice) {
        if (!checkAuth()) return;

        // Получаем даты из поиска (если есть)
        const searchDates = JSON.parse(localStorage.getItem('searchDates') || '{}');

        // Сохраняем выбранный номер для бронирования
        localStorage.setItem('selectedRoom', JSON.stringify({
            id: roomId,
            roomNumber,
            type: roomType,
            price: roomPrice,
            checkIn: searchDates.checkIn,
            checkOut: searchDates.checkOut
        }));

        // Переходим на страницу брони
        window.location.href = '/pages/booking.html';
    };

    // Применение фильтров
    applyFilters.addEventListener('click', applyFilter);

    // Загрузка при старте
    loadRooms();
})();