export const tokenKey = 'pc_token';
export const baseUrl = ''; // тот же хост/порт

export const api = {
    token: () => localStorage.getItem(tokenKey),
    setToken: (t) => localStorage.setItem(tokenKey, t),
    clearToken: () => localStorage.removeItem(tokenKey),

    async request(path, method='GET', body){
        const opt = { method, headers: { 'Content-Type':'application/json' } };
        const t = api.token(); if (t) opt.headers.Authorization = 'Bearer ' + t;
        if (body) opt.body = JSON.stringify(body);
        const res = await fetch(baseUrl + path, opt);
        let data = {}; try { data = await res.json(); } catch {}
        if (!res.ok && !data.error) data.error = 'HTTP_' + res.status;
        return data;
    },
    get: (p)=>api.request(p,'GET'),
    post:(p,b)=>api.request(p,'POST',b)
};

export const fmtDate = (iso)=>{ try { return new Date(iso).toLocaleString(); } catch { return iso; } };
export const esc = (s='')=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'","&#39;");
export const escAttr = (s='')=>String(s).replaceAll('"','&quot;');
