import { api, esc, tokenKey } from './api.js';

/* ===== Авторизация / logout ===== */
const goLogin = () => { localStorage.removeItem(tokenKey); window.location.assign(`${location.origin}/index.html`); };
if (!api.token()) goLogin();
document.getElementById('logoutBtn')?.addEventListener('click', goLogin);

async function ensureAuth() {
    const me = await api.get('/auth/me');
    if (!me?.id) goLogin();
    return me;
}

/* ===== Элементы ===== */
const form = document.getElementById('fAddFriend');
const msg = document.getElementById('msg');
const list = document.getElementById('friendsList');

/* ===== Логика ===== */
async function loadFriends() {
    await ensureAuth();
    const r = await api.get('/friends');
    if (!Array.isArray(r) || !r.length) {
        list.classList.add('placeholder');
        list.textContent = 'Пока пусто';
        return;
    }
    list.classList.remove('placeholder');
    list.innerHTML = r.map(x => `<div><b>${esc(x.name || '')}</b> — ${esc(x.email || '')}</div>`).join('');
}

form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    msg.textContent = '';
    const body = Object.fromEntries(new FormData(form));
    const r = await api.post('/friends', body);
    if (r?.ok) {
        form.reset();
        loadFriends();
    } else {
        msg.textContent = r?.error === 'USER_NOT_FOUND'
            ? 'Пользователь с таким email не найден'
            : 'Ошибка добавления';
    }
});

/* ===== Старт ===== */
loadFriends();