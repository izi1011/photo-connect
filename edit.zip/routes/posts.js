const { Router } = require('express');
const pool = require('../db');
const auth = require('../middlewares/auth');
const router = Router();

router.get('/', async (_req, res) => {
    const [rows] = await pool.query(`
        SELECT p.id, u.name AS author, p.content, p.photo_url, p.created_at
        FROM posts p JOIN users u ON u.id=p.user_id
        ORDER BY p.id DESC
    `);
    res.json(rows);
});

router.get('/my', auth, async (req, res) => {
    const [rows] = await pool.query(`
        SELECT p.id, u.name AS author, p.content, p.photo_url, p.created_at
        FROM posts p JOIN users u ON u.id=p.user_id
        WHERE p.user_id=? ORDER BY p.id DESC
    `, [req.userId]);
    res.json(rows);
});

router.post('/', auth, async (req, res) => {
    const content = String(req.body.content || '').trim();
    const photo_url = String(req.body.photo_url || '').trim() || null;
    if (!content) return res.status(400).json({ error: 'CONTENT_REQUIRED' });
    const [r] = await pool.query(
        'INSERT INTO posts(user_id,content,photo_url) VALUES (?,?,?)',
        [req.userId, content, photo_url]
    );
    res.json({ id: r.insertId });
});

module.exports = router;
