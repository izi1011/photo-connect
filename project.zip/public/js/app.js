// Главная страница - поиск номеров
(function initMain() {
    const searchForm = document.getElementById('searchForm');
    const searchError = document.getElementById('searchError');
    const featuredRooms = document.getElementById('featuredRooms');

    if (!searchForm) return;

    // Загрузка популярных номеров
    async function loadFeaturedRooms() {
        try {
            const res = await fetch('/api/rooms');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const rooms = await res.json();

            // Берем первые 3 номера как популярные
            const featured = rooms.slice(0, 3);
            renderFeaturedRooms(featured);
        } catch (err) {
            console.error('Ошибка загрузки номеров:', err);
            featuredRooms.innerHTML = '<div class="placeholder">Ошибка загрузки номеров</div>';
        }
    }

    function renderFeaturedRooms(rooms) {
        if (!rooms || !rooms.length) {
            featuredRooms.innerHTML = '<div class="placeholder">Номера не найдены</div>';
            return;
        }

        featuredRooms.innerHTML = rooms.map(room => `
            <div class="room-card">
                <div class="room-header">
                    <div class="room-number">№${escapeHtml(room.roomNumber)}</div>
                    <div class="type-badge">${escapeHtml(room.type)}</div>
                </div>
                <div class="room-price">${room.price} ₽/ночь</div>
                <button class="book-btn" onclick="location.href='/pages/rooms.html'">
                    Выбрать номер
                </button>
            </div>
        `).join('');
    }

    function escapeHtml(str = '') {
        return String(str)
            .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;').replaceAll("'", '&#039;');
    }

    // Валидация дат поиска
    searchForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const checkIn = document.getElementById('checkIn').value;
        const checkOut = document.getElementById('checkOut').value;

        if (!checkIn || !checkOut) {
            searchError.textContent = 'Заполните обе даты';
            searchError.style.display = 'block';
            return;
        }

        const checkInDate = new Date(checkIn);
        const checkOutDate = new Date(checkOut);

        if (checkInDate >= checkOutDate) {
            searchError.textContent = 'Дата выезда должна быть позже даты заезда';
            searchError.style.display = 'block';
            return;
        }

        // Сохраняем даты в localStorage для использования в rooms.html
        localStorage.setItem('searchDates', JSON.stringify({
            checkIn,
            checkOut
        }));

        // Переходим к каталогу
        window.location.href = '/pages/rooms.html';
    });

    loadFeaturedRooms();
})();