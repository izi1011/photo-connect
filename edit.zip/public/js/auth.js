import { api, tokenKey } from './api.js';

const tabReg = document.getElementById('tab-register');
const tabLog = document.getElementById('tab-login');
const formReg = document.getElementById('form-register');
const formLog = document.getElementById('form-login');
const msgReg = document.getElementById('msgReg');
const msgLogin = document.getElementById('msgLogin');
const authed = document.getElementById('authed');
const meName = document.getElementById('meName');
const meEmail = document.getElementById('meEmail');

function showTab(which){
    const isReg = which==='reg';
    formReg?.classList.toggle('hidden', !isReg);
    formLog?.classList.toggle('hidden', isReg);
    tabReg?.setAttribute('aria-selected', isReg);
    tabLog?.setAttribute('aria-selected', !isReg);
}
tabReg?.addEventListener('click', ()=>showTab('reg'));
tabLog?.addEventListener('click', ()=>showTab('log'));
showTab('reg');

async function refreshMe(){
    const t = api.token(); if (!t) return;
    const me = await api.get('/auth/me');
    if (me?.id && authed){
        meName.textContent = me.name || 'Пользователь';
        meEmail.textContent = me.email || '';
        authed.classList.remove('hidden');
    }
}
refreshMe();

formReg?.addEventListener('submit', async (e)=>{
    e.preventDefault(); msgReg.textContent='';
    const body = Object.fromEntries(new FormData(formReg));
    const r = await api.post('/auth/register', body);
    if (r?.error) msgReg.textContent = r.error==='EMAIL_TAKEN' ? 'Email занят' : 'Ошибка регистрации';
    else { showTab('log'); msgReg.textContent='Регистрация успешна. Войдите.'; }
});

formLog?.addEventListener('submit', async (e)=>{
    e.preventDefault(); msgLogin.textContent='';
    const body = Object.fromEntries(new FormData(formLog));
    const r = await api.post('/auth/login', body);
    if (r?.token){
        api.setToken(r.token);
        window.location.assign(`${location.origin}/pages/profile.html`);
    } else {
        msgLogin.textContent = 'Неверные данные';
    }
});

document.getElementById('logoutBtn')?.addEventListener('click', ()=>{
    localStorage.removeItem(tokenKey);
    window.location.assign(`${location.origin}/index.html`);
});
