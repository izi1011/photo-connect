const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));

const roomsRoutes = require('./data/rooms');
app.use('/api/rooms', roomsRoutes);

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => console.log(`HotelTime: http://localhost:${PORT}`));