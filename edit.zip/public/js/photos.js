import { api, esc, escAttr, tokenKey } from './api.js';

/* ===== Авторизация / logout ===== */
const goLogin = () => { localStorage.removeItem(tokenKey); window.location.assign(`${location.origin}/index.html`); };
if (!api.token()) goLogin();
document.getElementById('logoutBtn')?.addEventListener('click', goLogin);

async function ensureAuth() {
    const me = await api.get('/auth/me');
    if (!me?.id) goLogin();
    return me;
}

/* ===== Элементы ===== */
const form = document.getElementById('fPhoto');
const msg  = document.getElementById('msg');
const grid = document.getElementById('grid');

/* ===== Логика ===== */
async function loadPhotos() {
    await ensureAuth();
    const list = await api.get('/photos');
    if (!Array.isArray(list) || !list.length) {
        grid.classList.add('placeholder');
        grid.textContent = 'Пока нет фото';
        return;
    }
    grid.classList.remove('placeholder');
    grid.innerHTML = list.map(p => `
    <figure>
      <img src="${escAttr(p.url || '')}" alt="img">
      <figcaption><span class="badge">Автор</span> ${esc(p.author || '')}${p.caption ? ' — ' + esc(p.caption) : ''}</figcaption>
    </figure>
  `).join('');
}

form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    msg.textContent = '';
    const body = Object.fromEntries(new FormData(form));
    const r = await api.post('/photos', body);
    if (r?.id) {
        form.reset();
        loadPhotos();
    } else {
        msg.textContent = r?.error === 'URL_REQUIRED'
            ? 'Укажите ссылку на изображение'
            : 'Ошибка публикации';
    }
});

/* ===== Старт ===== */
loadPhotos();
