// Глобальные переменные
let currentBookings = [];
let currentRooms = [];
let currentUsers = [];

// Проверка прав администратора
document.addEventListener('DOMContentLoaded', function() {
    console.log('Admin panel loading...');

    if (!window.auth || !window.auth.isAuthenticated()) {
        alert('Требуется авторизация');
        window.location.href = '../auth.html';
        return;
    }

    const user = window.auth.getUser();
    console.log('User role:', user.role);

    if (user.role !== 'admin') {
        alert('Требуются права администратора');
        window.location.href = '../index.html';
        return;
    }

    // Показываем имя админа
    document.getElementById('adminName').textContent = user.name;

    // Инициализация
    initTabs();
    loadStats();
    loadBookings();
    loadRooms();
    loadUsers();
    initModals();
});

// Инициализация вкладок
function initTabs() {
    const tabs = document.querySelectorAll('.admin-tab');
    const contents = document.querySelectorAll('.admin-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const target = tab.dataset.tab;

            // Активируем вкладку
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // Показываем контент
            contents.forEach(content => content.classList.remove('active'));
            document.getElementById(`${target}-content`).classList.add('active');
        });
    });
}

// Инициализация модальных окон
function initModals() {
    // Добавление номера
    document.getElementById('addRoomForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        await addRoom();
    });

    // Редактирование номера
    document.getElementById('editRoomForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        await updateRoom();
    });
}

// Загрузка статистики
async function loadStats() {
    try {
        const token = localStorage.getItem('hoteltime_token');

        // Загружаем все данные для статистики
        const [bookings, rooms, users] = await Promise.all([
            fetch('/api/admin/bookings', { headers: { 'Authorization': `Bearer ${token}` } }).then(r => r.json()),
            fetch('/api/rooms').then(r => r.json()),
            fetch('/api/admin/users', { headers: { 'Authorization': `Bearer ${token}` } }).then(r => r.json())
        ]);

        // Обновляем статистику
        document.getElementById('totalBookings').textContent = bookings.length || 0;
        document.getElementById('totalRooms').textContent = rooms.length || 0;
        document.getElementById('totalUsers').textContent = users.length || 0;

        // Расчет дохода
        const revenue = bookings.reduce((sum, booking) => {
            return sum + (parseInt(booking.totalPrice) || 0);
        }, 0);
        document.getElementById('revenue').textContent = revenue + ' ₽';

    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Загрузка бронирований
async function loadBookings() {
    try {
        const token = localStorage.getItem('hoteltime_token');
        const response = await fetch('/api/admin/bookings', {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) throw new Error('Ошибка загрузки бронирований');

        currentBookings = await response.json();
        displayBookings(currentBookings);

    } catch (error) {
        console.error('Error loading bookings:', error);
        document.getElementById('bookingsTable').innerHTML = `
            <div class="empty-state">
                <div>❌</div>
                <p>Ошибка загрузки бронирований</p>
            </div>
        `;
    }
}

// Отображение бронирований
function displayBookings(bookings) {
    const container = document.getElementById('bookingsTable');

    if (!bookings || !bookings.length) {
        container.innerHTML = `
            <div class="empty-state">
                <div>📭</div>
                <p>Нет бронирований</p>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Пользователь</th>
                    <th>Номер</th>
                    <th>Даты</th>
                    <th>Гости</th>
                    <th>Стоимость</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                ${bookings.map(booking => `
                    <tr>
                        <td>#${booking.id}</td>
                        <td>
                            <div><strong>${escapeHtml(booking.userName)}</strong></div>
                            <div style="color: var(--muted); font-size: 0.8em;">${escapeHtml(booking.userEmail)}</div>
                        </td>
                        <td>
                            <div><strong>№${escapeHtml(booking.room.roomNumber)}</strong></div>
                            <div style="color: var(--muted); font-size: 0.8em;">${escapeHtml(booking.room.type)}</div>
                        </td>
                        <td>
                            <div>${booking.checkIn}</div>
                            <div style="color: var(--muted); font-size: 0.8em;">${booking.checkOut}</div>
                        </td>
                        <td>${booking.guestsCount} чел.</td>
                        <td><strong>${booking.totalPrice} ₽</strong></td>
                        <td>
                            <select class="form-control" style="padding: 4px 8px; font-size: 0.8em;" 
                                    onchange="updateBookingStatus(${booking.id}, this.value)">
                                <option value="pending" ${booking.status === 'pending' ? 'selected' : ''}>Ожидание</option>
                                <option value="confirmed" ${booking.status === 'confirmed' ? 'selected' : ''}>Подтверждено</option>
                                <option value="cancelled" ${booking.status === 'cancelled' ? 'selected' : ''}>Отменено</option>
                            </select>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-danger btn-sm" onclick="deleteBooking(${booking.id})">Удалить</button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Загрузка номеров
async function loadRooms() {
    try {
        const response = await fetch('/api/rooms');
        if (!response.ok) throw new Error('Ошибка загрузки номеров');

        currentRooms = await response.json();
        displayRooms(currentRooms);

    } catch (error) {
        console.error('Error loading rooms:', error);
        document.getElementById('roomsTable').innerHTML = `
            <div class="empty-state">
                <div>❌</div>
                <p>Ошибка загрузки номеров</p>
            </div>
        `;
    }
}

// Отображение номеров
function displayRooms(rooms) {
    const container = document.getElementById('roomsTable');

    if (!rooms || !rooms.length) {
        container.innerHTML = `
            <div class="empty-state">
                <div>🏨</div>
                <p>Нет номеров</p>
                <button class="btn-primary btn-sm" onclick="showAddRoomModal()" style="margin-top: 10px;">Добавить первый номер</button>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Номер</th>
                    <th>Тип</th>
                    <th>Цена</th>
                    <th>Статус</th>
                    <th>Дата добавления</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                ${rooms.map(room => `
                    <tr>
                        <td>#${room.id}</td>
                        <td><strong>№${escapeHtml(room.roomNumber)}</strong></td>
                        <td>${escapeHtml(room.type)}</td>
                        <td><strong>${room.price} ₽</strong></td>
                        <td>
                            <span class="status-badge status-${room.status || 'available'}">
                                ${getStatusText(room.status)}
                            </span>
                        </td>
                        <td>${new Date(room.createdAt).toLocaleDateString()}</td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-primary btn-sm" onclick="editRoom(${room.id})">Изменить</button>
                                <button class="btn-danger btn-sm" onclick="deleteRoom(${room.id})">Удалить</button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Загрузка пользователей
async function loadUsers() {
    try {
        const token = localStorage.getItem('hoteltime_token');
        const response = await fetch('/api/admin/users', {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) throw new Error('Ошибка загрузки пользователей');

        currentUsers = await response.json();
        displayUsers(currentUsers);

    } catch (error) {
        console.error('Error loading users:', error);
        document.getElementById('usersTable').innerHTML = `
            <div class="empty-state">
                <div>❌</div>
                <p>Ошибка загрузки пользователей</p>
            </div>
        `;
    }
}

// Отображение пользователей
function displayUsers(users) {
    const container = document.getElementById('usersTable');

    if (!users || !users.length) {
        container.innerHTML = `
            <div class="empty-state">
                <div>👥</div>
                <p>Нет пользователей</p>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Имя</th>
                    <th>Email</th>
                    <th>Роль</th>
                    <th>Дата регистрации</th>
                </tr>
            </thead>
            <tbody>
                ${users.map(user => `
                    <tr>
                        <td>#${user.id}</td>
                        <td><strong>${escapeHtml(user.name)}</strong></td>
                        <td>${escapeHtml(user.email)}</td>
                        <td>
                            <span class="role-badge role-${user.role}">
                                ${user.role === 'admin' ? 'Администратор' : 'Пользователь'}
                            </span>
                        </td>
                        <td>${new Date(user.createdAt).toLocaleDateString()}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Функции для работы с модальными окнами
function showAddRoomModal() {
    document.getElementById('addRoomModal').style.display = 'block';
}

function hideAddRoomModal() {
    document.getElementById('addRoomModal').style.display = 'none';
    document.getElementById('addRoomForm').reset();
}

function showEditRoomModal() {
    document.getElementById('editRoomModal').style.display = 'block';
}

function hideEditRoomModal() {
    document.getElementById('editRoomModal').style.display = 'none';
}

// Добавление номера
async function addRoom() {
    try {
        const token = localStorage.getItem('hoteltime_token');
        const formData = new FormData(document.getElementById('addRoomForm'));
        const roomData = Object.fromEntries(formData);

        const response = await fetch('/api/admin/rooms', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(roomData)
        });

        if (!response.ok) throw new Error('Ошибка добавления номера');

        const newRoom = await response.json();
        showNotification('Номер успешно добавлен', 'success');
        hideAddRoomModal();
        loadRooms();
        loadStats();

    } catch (error) {
        console.error('Error adding room:', error);
        showNotification('Ошибка при добавлении номера', 'error');
    }
}

// Редактирование номера
function editRoom(roomId) {
    const room = currentRooms.find(r => r.id == roomId);
    if (!room) return;

    document.getElementById('editRoomId').value = room.id;
    document.getElementById('editRoomNumber').value = room.roomNumber;
    document.getElementById('editRoomType').value = room.type;
    document.getElementById('editRoomPrice').value = room.price;
    document.getElementById('editRoomStatus').value = room.status || 'available';

    showEditRoomModal();
}

// Обновление номера
async function updateRoom() {
    try {
        const token = localStorage.getItem('hoteltime_token');
        const formData = new FormData(document.getElementById('editRoomForm'));
        const roomData = Object.fromEntries(formData);

        const response = await fetch(`/api/admin/rooms/${roomData.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(roomData)
        });

        if (!response.ok) throw new Error('Ошибка обновления номера');

        showNotification('Номер успешно обновлен', 'success');
        hideEditRoomModal();
        loadRooms();

    } catch (error) {
        console.error('Error updating room:', error);
        showNotification('Ошибка при обновлении номера', 'error');
    }
}

// Удаление номера
async function deleteRoom(roomId) {
    if (!confirm('Вы уверены, что хотите удалить этот номер?')) return;

    try {
        const token = localStorage.getItem('hoteltime_token');
        const response = await fetch(`/api/admin/rooms/${roomId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) throw new Error('Ошибка удаления номера');

        showNotification('Номер успешно удален', 'success');
        loadRooms();
        loadStats();

    } catch (error) {
        console.error('Error deleting room:', error);
        showNotification('Ошибка при удалении номера', 'error');
    }
}

// Обновление статуса бронирования
async function updateBookingStatus(bookingId, status) {
    try {
        const token = localStorage.getItem('hoteltime_token');
        const response = await fetch(`/api/admin/bookings/${bookingId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ status })
        });

        if (!response.ok) throw new Error('Ошибка обновления статуса');

        showNotification('Статус бронирования обновлен', 'success');
        loadBookings();

    } catch (error) {
        console.error('Error updating booking status:', error);
        showNotification('Ошибка при обновлении статуса', 'error');
    }
}

// Удаление бронирования
async function deleteBooking(bookingId) {
    if (!confirm('Вы уверены, что хотите удалить это бронирование?')) return;

    try {
        const token = localStorage.getItem('hoteltime_token');
        const response = await fetch(`/api/admin/bookings/${bookingId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) throw new Error('Ошибка удаления бронирования');

        showNotification('Бронирование успешно удалено', 'success');
        loadBookings();
        loadStats();

    } catch (error) {
        console.error('Error deleting booking:', error);
        showNotification('Ошибка при удалении бронирования', 'error');
    }
}

// Вспомогательные функции
function escapeHtml(str = '') {
    return String(str).replace(/[&<>"']/g, match => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[match]));
}

function getStatusText(status) {
    const statusMap = {
        'available': 'Свободен',
        'occupied': 'Занят',
        'maintenance': 'Обслуживание',
        'pending': 'Ожидание',
        'confirmed': 'Подтверждено',
        'cancelled': 'Отменено'
    };
    return statusMap[status] || 'Свободен';
}

function showNotification(message, type = 'success') {
    // Создаем временное уведомление
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 10000;
        animation: slideInRight 0.3s ease;
        background: ${type === 'success' ? 'var(--accent1)' : 'var(--danger)'};
        color: #000;
    `;
    notification.textContent = message;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Добавляем анимацию для уведомлений
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);