const roomsList = document.getElementById('roomsList');
const roomNumberInput = document.getElementById('roomNumber');
const typeInput = document.getElementById('type');
const priceInput = document.getElementById('price');
const addRoomBtn = document.getElementById('addRoomBtn');

function fmtDate(iso) {
    try { return new Date(iso).toLocaleDateString(); } catch { return iso; }
}

function escapeHtml(str = '') {
    return String(str)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function renderRooms(rooms) {
    if (!rooms.length) {
        roomsList.innerHTML = '<div class="placeholder empty">Номера появятся здесь. Добавьте первый номер!</div>';
        return;
    }

    roomsList.innerHTML = rooms.map(room => `
        <div class="room-card">
            <div class="room-header">
                <div class="room-number">№${escapeHtml(room.roomNumber)}</div>
                <div class="type-badge">${escapeHtml(room.type)}</div>
            </div>
            <div class="room-price">${room.price} ₽/ночь</div>
            <div class="room-meta">Добавлен: ${fmtDate(room.createdAt)}</div>
            <button class="book-btn" onclick="bookRoom(${room.id})">
                🗓️ Забронировать
            </button>
        </div>
    `).join('');
}
function bookRoom(roomId) {
    alert(`🗓️ Бронирование номера ID: ${roomId}\n(функционал в разработке)`);
}

async function loadRooms() {
    try {
        const res = await fetch('/api/rooms');
        const data = await res.json();
        renderRooms(data);
    } catch (err) {
        console.error('Ошибка загрузки номеров:', err);
    }
}

addRoomBtn.addEventListener('click', async () => {
    const roomNumber = roomNumberInput.value.trim();
    const type = typeInput.value.trim();
    const price = priceInput.value.trim();

    if (!roomNumber || !type || !price) {
        return alert('Заполните все поля!');
    }

    try {
        const res = await fetch('/api/rooms', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ roomNumber, type, price })
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            return alert('Ошибка: ' + (err.error || res.status));
        }

        roomNumberInput.value = "";
        typeInput.value = "";
        priceInput.value = "";

        await loadRooms();
    } catch (err) {
        alert('Ошибка сети!');
    }
});

loadRooms();