window.renderErrors = function renderErrors(details = [], ulEl) {
    if (!ulEl) return;
    ulEl.innerHTML = "";
    details.forEach(e => {
        const li = document.createElement('li');
        li.textContent = `${e.field}: ${e.message}`;
        ulEl.appendChild(li);
    });
};

window.highlightFields = function highlightFields(details = [], formEl) {
    if (!formEl) return;
    formEl.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
    details.forEach(e => {
        const el = formEl.querySelector(`[name="${e.field}"], #${e.field}`);
        if (el) el.classList.add('is-invalid');
    });
};