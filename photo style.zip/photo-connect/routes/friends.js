const { Router } = require('express');
const pool = require('../db');
const auth = require('../middlewares/auth');
const router = Router();

router.get('/', auth, async (req, res) => {
    const [rows] = await pool.query(`
        SELECT u.name, u.email
        FROM friends f JOIN users u ON u.id=f.friend_id
        WHERE f.user_id=?`, [req.userId]);
    res.json(rows);
});

router.post('/', auth, async (req, res) => {
    const email = String(req.body.friend_email || '').trim();
    const [u] = await pool.query('SELECT id FROM users WHERE email=?', [email]);
    if (!u.length) return res.status(404).json({ error: 'USER_NOT_FOUND' });
    await pool.query('INSERT IGNORE INTO friends(user_id, friend_id) VALUES (?,?)',
        [req.userId, u[0].id]);
    res.json({ ok: true });
});

module.exports = router;