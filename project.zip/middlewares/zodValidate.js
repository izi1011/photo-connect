/**
 * Универсальный middleware для Zod-схем.
 * Если схема проходит --- вызывает next().
 * Если нет --- возвращает 400 с details[].
 */
module.exports = (schema) => (req, res, next) => {
    const result = schema.safeParse(req.body);
    if (result.success) {
        req.body = result.data; // очищенные данные
        return next();
    }

    const details = result.error.issues.map(i => ({
        field: i.path.join('.'),
        message: i.message
    }));

    res.status(400).json({
        error: 'VALIDATION_ERROR',
        details
    });
};