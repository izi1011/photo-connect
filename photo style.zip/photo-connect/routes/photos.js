const { Router } = require('express');
const pool = require('../db');
const auth = require('../middlewares/auth');
const router = Router();

router.get('/', async (_req, res) => {
    const [rows] = await pool.query(`
    SELECT p.id, u.name AS author, p.url, p.caption, p.created_at
    FROM photos p JOIN users u ON u.id=p.user_id
    ORDER BY p.id DESC
  `);
    res.json(rows);
});

router.post('/', auth, async (req, res) => {
    const url = String(req.body.url || '').trim();
    const caption = String(req.body.caption || '').trim();
    if (!url) return res.status(400).json({ error: 'URL_REQUIRED' });
    const [r] = await pool.query(
        'INSERT INTO photos(user_id,url,caption) VALUES (?,?,?)',
        [req.userId, url, caption || null]
    );
    res.json({ id: r.insertId });
});

module.exports = router;