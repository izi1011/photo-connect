const API = '/api/items';
const gallery = document.getElementById('gallery');

async function loadGallery() {
    const res = await fetch(API);
    const data = await res.json();

    gallery.innerHTML = data
        .filter(item => item.image)
        .map(item => `
      <div class="gallery-item">
        <img src="${item.image}" alt="${item.title}">
        <div><strong>${item.title}</strong></div>
        <div>${item.note || ''}</div>
        <small>${new Date(item.date_created).toLocaleDateString()}</small>
      </div>
    `).join('');
}

loadGallery();